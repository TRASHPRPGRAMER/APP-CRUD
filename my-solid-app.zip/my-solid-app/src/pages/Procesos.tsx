/* src/pages/Procesos.tsx */
import type { Component } from "solid-js";
import { createSignal, For } from "solid-js";
import PouchDB from "pouchdb";

const db = new PouchDB("procesos");

interface Proceso {
  _id?: string;
  descripcion: string;
}

const Procesos: Component = () => {
  const [procesos, setProcesos] = createSignal<Proceso[]>([]);
  const [descripcion, setDescripcion] = createSignal("");

  const cargarProcesos = async () => {
    const result = await db.allDocs<Proceso>({ include_docs: true });
    setProcesos(result.rows.map((row) => row.doc as Proceso));
  };

  const agregarProceso = async () => {
    if (descripcion()) {
      await db.put({ _id: new Date().toISOString(), descripcion: descripcion() });
      setDescripcion("");
      cargarProcesos();
    }
  };

  const eliminarProceso = async (id: string) => {
    const doc = await db.get(id);
    await db.remove(doc);
    cargarProcesos();
  };

  cargarProcesos(); // Carga inicial de procesos.

  return (
    <div style={{ background: "white", padding: "20px" }}>
      <h1>Gestión de Procesos</h1>
      <input
        type="text"
        placeholder="Descripción del proceso"
        value={descripcion()}
        onInput={(e) => setDescripcion((e.target as HTMLInputElement).value)}
        style={{ margin: "10px", padding: "10px" }}
      />
      <button
        onClick={agregarProceso}
        style={{
          background: "green",
          color: "white",
          padding: "10px 20px",
        }}
      >
        Agregar Proceso
      </button>
      <ul>
        <For each={procesos()}>
          {(proceso) => (
            <li>
              {proceso.descripcion}{" "}
              <button
                onClick={() => proceso._id && eliminarProceso(proceso._id)}
                style={{
                  background: "red",
                  color: "white",
                  margin: "5px",
                  padding: "5px 10px",
                }}
              >
                Eliminar
              </button>
            </li>
          )}
        </For>
      </ul>
    </div>
  );
};

export default Procesos;
