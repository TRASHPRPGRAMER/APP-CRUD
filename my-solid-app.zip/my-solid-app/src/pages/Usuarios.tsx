/* src/pages/Usuarios.tsx */
import type { Component } from "solid-js";
import { createSignal, For } from "solid-js";
import PouchDB from "pouchdb";

const db = new PouchDB("usuarios");

interface Usuario {
  _id?: string;
  nombre: string;
}

const Usuarios: Component = () => {
  const [usuarios, setUsuarios] = createSignal<Usuario[]>([]);
  const [nombre, setNombre] = createSignal("");

  const cargarUsuarios = async () => {
    const result = await db.allDocs<Usuario>({ include_docs: true });
    setUsuarios(result.rows.map((row) => row.doc as Usuario));
  };

  const agregarUsuario = async () => {
    if (nombre()) {
      await db.put({ _id: new Date().toISOString(), nombre: nombre() });
      setNombre("");
      cargarUsuarios();
    }
  };

  const eliminarUsuario = async (id: string) => {
    const doc = await db.get(id);
    await db.remove(doc);
    cargarUsuarios();
  };

  cargarUsuarios(); // Carga inicial de usuarios.

  return (
    <div style={{ background: "white", padding: "20px" }}>
      <h1>Gestión de Usuarios</h1>
      <input
        type="text"
        placeholder="Nombre del usuario"
        value={nombre()}
        onInput={(e) => setNombre((e.target as HTMLInputElement).value)}
        style={{ margin: "10px", padding: "10px" }}
      />
      <button
        onClick={agregarUsuario}
        style={{
          background: "green",
          color: "white",
          padding: "10px 20px",
        }}
      >
        Agregar Usuario
      </button>
      <ul>
        <For each={usuarios()}>
          {(usuario) => (
            <li>
              {usuario.nombre}{" "}
              <button
                onClick={() => usuario._id && eliminarUsuario(usuario._id)}
                style={{
                  background: "red",
                  color: "white",
                  margin: "5px",
                  padding: "5px 10px",
                }}
              >
                Eliminar
              </button>
            </li>
          )}
        </For>
      </ul>
    </div>
  );
};

export default Usuarios;
