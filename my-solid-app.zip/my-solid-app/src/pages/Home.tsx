/* src/pages/Home.tsx */
import { Link } from "solid-app-router";
import type { Component } from "solid-js";

const Home: Component = () => {
  return (
    <div style={{ background: "white", padding: "20px"}}>
      <h1>Gestión de Usuarios y Procesos</h1>
      <Link href="/usuarios">
        <button
          style={{
            background: "green",
            color: "white",
            margin: "10px",
            padding: "10px 20px",
          }}
        >
          Gestión de Usuarios
        </button>
      </Link>
      <Link href="/procesos">
        <button
          style={{
            background: "green",
            color: "white",
            margin: "10px",
            padding: "10px 20px",
          }}
        >
          Gestión de Procesos
        </button>
      </Link>
    </div>
  );
};

export default Home;

