/* src/main.tsx */
import { render } from "solid-js/web";
import { Router, Routes, Route } from "solid-app-router";
import Home from "./pages/Home";
import Usuarios from "./pages/Usuarios";
import Procesos from "./pages/Procesos";
render(() => (
  <Router>
    <Routes>
      <Route path="/" component={Home} />
      <Route path="/usuarios" component={Usuarios} />
      <Route path="/procesos" component={Procesos} />
    </Routes>
  </Router>
), document.getElementById("root") as HTMLElement);

